zip -r bundle.zip . -x *.git* -x pack.sh
