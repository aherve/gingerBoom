setTimeout(function () {
  window.close()
}, 3100)
