# gingerBoom
Have a clown-disguised GingerGM shout "BOOM" in a single click
